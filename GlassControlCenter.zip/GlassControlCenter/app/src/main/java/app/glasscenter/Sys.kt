package app.glasscenter

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.os.SystemClock

/** Everything the control center reads or changes on the phone. */
class Sys(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val conn = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager

    var torchOn = false
    private var torchId: String? = null
    var torchMax = 1
    var torchLevel = 1

    init {
        try {
            for (id in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(id)
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    torchId = id
                    if (Build.VERSION.SDK_INT >= 33) {
                        torchMax = ch.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                    }
                    break
                }
            }
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torchOn = enabled
                }
            }, null)
        } catch (e: Exception) {
        }
    }

    // ---- launching -------------------------------------------------------------------------
    fun start(i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (e: Exception) { false }
    }

    fun startAny(vararg intents: Intent) {
        for (i in intents) if (start(i)) return
    }

    // ---- permissions ----------------------------------------------------------------------
    fun canWrite(): Boolean = Settings.System.canWrite(ctx)
    fun requestWrite() {
        start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }
    fun dndAccess(): Boolean = nm.isNotificationPolicyAccessGranted
    fun requestDnd() { start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }

    // ---- brightness / volume ---------------------------------------------------------------
    fun brightness(): Float = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (e: Exception) { 0.5f }

    fun setBrightness(f: Float) {
        if (!canWrite()) { requestWrite(); return }
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                (f * 255f).toInt().coerceIn(1, 255))
        } catch (e: Exception) {
        }
    }

    fun volume(): Float {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max == 0) 0f else am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
    }

    fun setVolume(f: Float) {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).toInt().coerceIn(0, max), 0) } catch (e: Exception) {}
    }

    // ---- ringer / focus / rotation -----------------------------------------------------------
    fun silent(): Boolean = am.ringerMode != AudioManager.RINGER_MODE_NORMAL
    fun toggleSilent() {
        try {
            am.ringerMode = if (silent()) AudioManager.RINGER_MODE_NORMAL else AudioManager.RINGER_MODE_VIBRATE
        } catch (e: SecurityException) { requestDnd() }
    }

    fun focusOn(): Boolean = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
        nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN

    fun toggleFocus() {
        if (!dndAccess()) { requestDnd(); return }
        nm.setInterruptionFilter(
            if (focusOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY)
    }

    fun rotationLocked(): Boolean = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION) == 0
    } catch (e: Exception) { false }

    fun toggleRotation() {
        if (!canWrite()) { requestWrite(); return }
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (rotationLocked()) 1 else 0)
        } catch (e: Exception) {}
    }

    // ---- torch -----------------------------------------------------------------------------------
    fun hasTorch(): Boolean = torchId != null
    fun setTorch(on: Boolean, level: Int = -1) {
        val id = torchId ?: return
        try {
            if (on && Build.VERSION.SDK_INT >= 33 && torchMax > 1) {
                val l = (if (level > 0) level else torchLevel).coerceIn(1, torchMax)
                torchLevel = l
                cm.turnOnTorchWithStrengthLevel(id, l)
            } else {
                cm.setTorchMode(id, on)
            }
            torchOn = on
        } catch (e: Exception) {
        }
    }

    // ---- connectivity state --------------------------------------------------------------------
    fun airplane(): Boolean = Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    fun wifiOn(): Boolean = try { wifi.isWifiEnabled } catch (e: Exception) { false }
    @Suppress("DEPRECATION")
    fun ssid(): String? = try {
        val s = wifi.connectionInfo?.ssid
        if (s == null || s == "<unknown ssid>" || s == "0x") null else s.trim('"')
    } catch (e: Exception) { null }

    fun caps(): NetworkCapabilities? = try { conn.getNetworkCapabilities(conn.activeNetwork) } catch (e: Exception) { null }
    fun dataOn(): Boolean = caps()?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    fun vpnOn(): Boolean = caps()?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
    fun btOn(): Boolean = try {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) { false }
    fun nfcOn(): Boolean = try {
        (ctx.getSystemService(Context.NFC_SERVICE) as NfcManager).defaultAdapter?.isEnabled == true
    } catch (e: Exception) { false }
    fun hotspotOn(): Boolean = try {
        val m = wifi.javaClass.getDeclaredMethod("isWifiApEnabled")
        m.isAccessible = true
        m.invoke(wifi) as Boolean
    } catch (e: Throwable) { false }
    fun saverOn(): Boolean = pm.isPowerSaveMode
    fun carrier(): String {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
        val n = try { tm.networkOperatorName } catch (e: Exception) { "" }
        return if (n.isNullOrEmpty()) "No Service" else n
    }

    // ---- battery -----------------------------------------------------------------------------------
    class Batt(val pct: Int, val charging: Boolean)
    fun battery(): Batt {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 50) ?: 50
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return Batt(level * 100 / scale, ch)
    }

    // ---- actions ------------------------------------------------------------------------------------
    fun openAirplane() = startAny(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun openWifi() {
        if (Build.VERSION.SDK_INT >= 29) startAny(Intent(Settings.Panel.ACTION_WIFI), Intent(Settings.ACTION_WIFI_SETTINGS))
        else startAny(Intent(Settings.ACTION_WIFI_SETTINGS))
    }
    fun openData() {
        if (Build.VERSION.SDK_INT >= 29) startAny(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY), Intent(Settings.ACTION_WIRELESS_SETTINGS))
        else startAny(Intent(Settings.ACTION_WIRELESS_SETTINGS))
    }
    fun openBluetooth() = startAny(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openHotspot() = startAny(
        Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun openVpn() = startAny(Intent(Settings.ACTION_VPN_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun openNfc() = startAny(Intent(Settings.ACTION_NFC_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun openShare() = startAny(
        Intent("com.google.android.gms.settings.ADVANCED_DEVICE_SHARING"),
        Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openDisplay() = startAny(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    fun openSound() = startAny(Intent(Settings.ACTION_SOUND_SETTINGS))
    fun openCast() = startAny(Intent(Settings.ACTION_CAST_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
    fun openSaver() = startAny(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Settings.ACTION_SETTINGS))
    fun openFocus() = startAny(Intent("android.settings.ZEN_MODE_SETTINGS"), Intent(Settings.ACTION_SOUND_SETTINGS))
    fun openCamera() = startAny(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun openCalculator() = startAny(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
    fun openQr() = startAny(Intent("com.google.zxing.client.android.SCAN"), Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun openSettings() = startAny(Intent(Settings.ACTION_SETTINGS))
    fun openStopwatch() = startAny(Intent(AlarmClock.ACTION_SHOW_TIMERS), Intent(AlarmClock.ACTION_SHOW_ALARMS))
    fun openAlarm() = startAny(Intent(AlarmClock.ACTION_SET_ALARM), Intent(AlarmClock.ACTION_SHOW_ALARMS))
    fun startTimer(seconds: Int) {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (!start(i)) startAny(Intent(AlarmClock.ACTION_SHOW_TIMERS))
    }

    fun openRecorder(fallbackScreenshot: () -> Unit) {
        val pkgs = listOf("com.transsion.screenrecorder", "com.miui.screenrecorder", "com.samsung.android.app.smartcapture",
            "com.oplus.screenrecorder", "com.coloros.screenrecorder", "com.google.android.apps.screenrecorder")
        for (p in pkgs) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p)
            if (i != null && start(i)) return
        }
        fallbackScreenshot()
    }
}

/** Tracks the active media session so the media card can show title, art and controls. */
class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() {
        MediaHub.attach(applicationContext)
    }
}

object MediaHub {
    var controller: MediaController? = null
        private set
    private val listeners = ArrayList<() -> Unit>()
    private var attached = false

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { fire() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { fire() }
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun fire() { for (l in ArrayList(listeners)) l() }

    fun attach(ctx: Context) {
        try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(ctx, MediaListener::class.java)
            if (!attached) {
                msm.addOnActiveSessionsChangedListener({ list -> pick(list ?: emptyList()) }, cn)
                attached = true
            }
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
        } catch (e: Exception) {
        }
    }

    private fun pick(list: List<MediaController>) {
        controller?.unregisterCallback(cb)
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        controller = c
        c?.registerCallback(cb)
        fire()
    }

    fun title(): String = controller?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Not Playing"
    fun artist(): String = controller?.metadata?.let {
        it.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: it.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
    } ?: ""
    fun art(): Bitmap? = controller?.metadata?.let {
        it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: it.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    }
    fun playing(): Boolean = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
    fun duration(): Long = controller?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
    fun position(): Long {
        val s = controller?.playbackState ?: return 0L
        if (s.state != PlaybackState.STATE_PLAYING) return s.position
        val dt = SystemClock.elapsedRealtime() - s.lastPositionUpdateTime
        return s.position + (dt * s.playbackSpeed).toLong()
    }
    fun toggle() {
        val t = controller?.transportControls ?: return
        if (playing()) t.pause() else t.play()
    }
    fun next() { controller?.transportControls?.skipToNext() }
    fun prev() { controller?.transportControls?.skipToPrevious() }
    fun seek(ms: Long) { controller?.transportControls?.seekTo(ms) }
}
