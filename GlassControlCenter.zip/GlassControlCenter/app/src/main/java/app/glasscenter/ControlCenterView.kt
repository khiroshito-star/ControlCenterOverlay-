package app.glasscenter

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Spec(val id: String, val name: String, val w: Int, val h: Int)

class BatteryView(ctx: Context) : View(ctx) {
    var pct = 50
    var charging = false
    var saver = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val tip = w * 0.07f
        val body = RectF(0f, 0f, w - tip - 1f, h)
        p.style = Paint.Style.STROKE
        p.strokeWidth = h * 0.09f
        p.color = Color.argb(120, 255, 255, 255)
        c.drawRoundRect(body, h * 0.3f, h * 0.3f, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb(120, 255, 255, 255)
        c.drawRoundRect(RectF(body.right + 1f, h * 0.33f, w, h * 0.67f), 2f, 2f, p)
        p.color = if (charging) Color.rgb(52, 199, 89) else if (saver || pct <= 20) Color.rgb(255, 204, 0) else Color.WHITE
        val inset = h * 0.14f
        val fw = (body.width() - inset * 2f) * pct.coerceIn(3, 100) / 100f
        c.drawRoundRect(RectF(inset, inset, inset + fw, h - inset), h * 0.2f, h * 0.2f, p)
    }
}

class ControlCenterView(private val svc: CCAccessibilityService) : FrameLayout(svc) {

    private val sys = svc.sys
    private val dn = resources.displayMetrics.density
    private val sz = svc.realSize()
    private val W = sz.x.toFloat()
    private val H = sz.y.toFloat()
    private val m = W * 0.097f
    private val cw = W - 2f * m
    private val gap = cw * 0.052f
    private val cell = (cw - 3f * gap) / 4f
    private val gridTop = H * 0.147f
    private val hd = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()

    var blurSetter: ((Int) -> Unit)? = null
    var closeRequest: (() -> Unit)? = null
    var progress = 0f
        private set

    private val blue = Color.rgb(10, 132, 255)
    private val red = Color.rgb(255, 59, 48)
    private val amber = Color.rgb(255, 204, 0)

    private val host = FrameLayout(svc)
    private val pagesBox = FrameLayout(svc)
    private val page0 = FrameLayout(svc)
    private val page1 = FrameLayout(svc)
    private val page2 = FrameLayout(svc)
    private val pageList = listOf(page0, page1, page2)
    private var pageF = 0f
    private var startPageF = 0f

    private val specs = listOf(
        Spec("conn", "Connectivity", 2, 2), Spec("media", "Now Playing", 2, 2),
        Spec("orient", "Orientation Lock", 1, 1), Spec("bell", "Silent Mode", 1, 1),
        Spec("bright", "Brightness", 1, 2), Spec("vol", "Volume", 1, 2),
        Spec("focus", "Focus", 2, 1), Spec("torch", "Flashlight", 1, 1),
        Spec("timer", "Timer", 1, 1), Spec("calc", "Calculator", 1, 1),
        Spec("cam", "Camera", 1, 1), Spec("mirror", "Screen Mirroring", 1, 1),
        Spec("qr", "Code Scanner", 1, 1), Spec("rec", "Screen Recording", 1, 1),
        Spec("saver", "Battery Saver", 1, 1), Spec("dolby", "Sound Effects", 1, 1),
        Spec("wpower", "Wireless Power Sharing", 1, 1)
    )
    private val tiles = LinkedHashMap<String, View>()

    private class Conn(val id: String, val title: String, val icon: Int)
    private val conns = listOf(
        Conn("air", "Airplane Mode", R.drawable.ic_airplane), Conn("share", "Quick Share", R.drawable.ic_share),
        Conn("wifi", "Wi-Fi", R.drawable.ic_wifi), Conn("data", "Mobile Data", R.drawable.ic_signal),
        Conn("bt", "Bluetooth", R.drawable.ic_bluetooth), Conn("hot", "Personal Hotspot", R.drawable.ic_link),
        Conn("vpn", "VPN", R.drawable.ic_globe), Conn("nfc", "NFC", R.drawable.ic_nfc)
    )
    private val blockBtns = HashMap<String, IconButton>()
    private val rowBtns = HashMap<String, IconButton>()
    private val rowSubs = HashMap<String, TextView>()
    private val rowViews = HashMap<String, View>()

    private lateinit var orientBtn: IconButton
    private lateinit var bellBtn: IconButton
    private lateinit var torchBtn: IconButton
    private lateinit var saverBtn: IconButton
    private lateinit var sliderB: SliderView
    private lateinit var sliderV: SliderView
    private lateinit var focusPill: FrameLayout
    private lateinit var focusBtn: IconButton
    private lateinit var focusTv: TextView
    private lateinit var plusBtn: IconButton
    private lateinit var doneTv: TextView
    private lateinit var addLabel: TextView
    private lateinit var carrierTv: TextView
    private lateinit var battTv: TextView
    private lateinit var battView: BatteryView
    private lateinit var rotIcon: ImageView
    private lateinit var homeBar: View
    private val indicators = ArrayList<ImageView>()

    // media widgets (mini card + full page)
    private lateinit var miniArt: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageView
    private lateinit var bigArt: ImageView
    private lateinit var bigTitle: TextView
    private lateinit var bigArtist: TextView
    private lateinit var bigPlay: ImageView
    private lateinit var bigSeek: SliderView
    private lateinit var bigVol: SliderView
    private lateinit var tPos: TextView
    private lateinit var tLen: TextView

    private var edit = false
    private val jiggles = ArrayList<ObjectAnimator>()
    private var popup: FrameLayout? = null
    private var progAnim: ValueAnimator? = null
    private var pageAnim: ValueAnimator? = null
    private var blurAnim: ValueAnimator? = null
    private var blurNow = 0f
    private var tick = 0
    private val mediaListener: () -> Unit = { hd.post { refreshMedia() } }

    private var dX = 0f
    private var dY = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null
    private fun dp(v: Float): Float = v * dn
    private val slop = 14f * dn

    private val ticker = object : Runnable {
        override fun run() {
            tick++
            refreshMediaProgress()
            if (tick % 3 == 0) refresh()
            hd.postDelayed(this, 500)
        }
    }

    init {
        isFocusableInTouchMode = true
        addView(host, FrameLayout.LayoutParams(-1, -1))
        host.addView(pagesBox, FrameLayout.LayoutParams(-1, -1))
        for (p in pageList) pagesBox.addView(p, FrameLayout.LayoutParams(-1, -1))
        buildTopBar()
        buildStatus()
        buildTiles()
        layoutGrid()
        buildMediaPage()
        buildListPage()
        buildIndicators()
        buildHomeBar()
        setPageF(0f)
        refresh()
        refreshMedia()
        setProgress(0f)
        MediaHub.attach(svc.applicationContext)
        MediaHub.addListener(mediaListener)
    }

    // ---------------------------------------------------------------- helpers
    private fun fl(w: Float, h: Float, x: Float, y: Float) =
        FrameLayout.LayoutParams(w.toInt(), h.toInt()).also { it.leftMargin = x.toInt(); it.topMargin = y.toInt() }

    private fun tvw(t: String, px: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(svc).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
        setTextColor(color)
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        includeFontPadding = false
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun icon(res: Int, color: Int = Color.WHITE): ImageView = ImageView(svc).apply {
        setImageResource(res)
        setColorFilter(color)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }

    private fun ibtn(res: Int, frac: Float = 0.48f): IconButton = IconButton(svc).apply {
        setIcon(res)
        iconFrac = frac
    }

    private fun buzz(v: View) {
        if (Prefs.haptics(svc)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun act(v: View, f: () -> Unit) {
        v.setOnClickListener { if (!edit) { buzz(v); f() } }
    }

    private fun lact(v: View, f: () -> Unit) {
        v.setOnLongClickListener { if (edit) false else { buzz(v); f(); true } }
    }

    private fun go(f: () -> Unit) {
        f()
        hd.postDelayed({ closeRequest?.invoke() }, 80)
    }

    private fun roundOutline(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) {
                o.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    // ---------------------------------------------------------------- top bar / status
    private fun buildTopBar() {
        val d = cell * 0.42f
        val y = H * 0.023f
        plusBtn = ibtn(R.drawable.ic_plus, 0.55f)
        host.addView(plusBtn, fl(d, d, m, y))
        act(plusBtn) { toggleEdit() }
        doneTv = tvw("Done", cell * 0.17f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GlassDrawable(dn)
            visibility = View.GONE
            setOnClickListener { exitEdit() }
        }
        host.addView(doneTv, fl(cell * 0.85f, d, m, y))
        val pw = ibtn(R.drawable.ic_power, 0.5f)
        host.addView(pw, fl(d, d, W - m - d, y))
        act(pw) { closeRequest?.invoke(); hd.postDelayed({ svc.power() }, 250) }
    }

    private fun buildStatus() {
        val cy = H * 0.115f
        val s = cell * 0.17f
        val sig = icon(R.drawable.ic_signal)
        host.addView(sig, fl(s, s, m + cell * 0.02f, cy - s / 2f))
        carrierTv = tvw("", cell * 0.17f, Color.WHITE, true)
        host.addView(carrierTv, fl(cell * 1.6f, cell * 0.22f, m + cell * 0.25f, cy - cell * 0.11f))
        rotIcon = icon(R.drawable.ic_lock_rotate)
        host.addView(rotIcon, fl(s * 1.05f, s * 1.05f, W - m - cell * 1.5f, cy - s / 2f))
        battTv = tvw("", cell * 0.17f, Color.WHITE, true).apply { gravity = Gravity.END }
        host.addView(battTv, fl(cell * 0.6f, cell * 0.22f, W - m - cell * 1.0f, cy - cell * 0.11f))
        battView = BatteryView(svc)
        host.addView(battView, fl(cell * 0.3f, cell * 0.15f, W - m - cell * 0.3f, cy - cell * 0.075f))
    }

    private fun buildIndicators() {
        val res = intArrayOf(R.drawable.ic_heart, R.drawable.ic_music, R.drawable.ic_share)
        val ys = floatArrayOf(0.4375f, 0.5f, 0.561f)
        val s = cell * 0.2f
        for (i in 0..2) {
            val iv = icon(res[i])
            val cx = W - m / 2f
            host.addView(iv, fl(s * 1.6f, s * 1.6f, cx - s * 0.8f, H * ys[i] - s * 0.8f))
            iv.setPadding((s * 0.3f).toInt(), (s * 0.3f).toInt(), (s * 0.3f).toInt(), (s * 0.3f).toInt())
            iv.setOnClickListener { if (!edit) goPage(i) }
            indicators.add(iv)
        }
    }

    private fun buildHomeBar() {
        homeBar = View(svc).apply {
            background = GradientDrawable().apply { cornerRadius = 20f; setColor(Color.argb(140, 255, 255, 255)) }
        }
        host.addView(homeBar, fl(W * 0.35f, dn * 4.5f, W * 0.325f, H - dn * 14f))
    }

    // ---------------------------------------------------------------- tiles
    private fun buildTiles() {
        tiles["conn"] = buildConn()
        tiles["media"] = buildMiniMedia()

        orientBtn = ibtn(R.drawable.ic_lock_rotate).apply { onIconColor = red }
        act(orientBtn) { sys.toggleRotation(); hd.postDelayed({ refresh() }, 150) }
        lact(orientBtn) { showOrientPopup(orientBtn) }
        tiles["orient"] = orientBtn

        bellBtn = ibtn(R.drawable.ic_bell).apply { offIconColor = amber; onFill = Color.rgb(255, 149, 0); onIconColor = Color.WHITE }
        act(bellBtn) { sys.toggleSilent(); hd.postDelayed({ refresh() }, 150) }
        tiles["bell"] = bellBtn

        sliderB = SliderView(svc).apply {
            setIcon(R.drawable.ic_sun)
            iconColor = Color.rgb(255, 196, 0)
            onChange = { sys.setBrightness(it) }
            onRelease = { buzz(this) }
        }
        tiles["bright"] = sliderB
        sliderV = SliderView(svc).apply {
            setIcon(R.drawable.ic_volume)
            iconColor = Color.rgb(24, 165, 232)
            onChange = { sys.setVolume(it) }
            onRelease = { buzz(this) }
        }
        tiles["vol"] = sliderV

        focusPill = FrameLayout(svc).apply { background = GlassDrawable(dn, -1f, 0, Color.rgb(52, 199, 89)) }
        focusBtn = ibtn(R.drawable.ic_moon, 0.5f).apply { isClickable = false; onIconColor = Color.rgb(94, 92, 230) }
        focusPill.addView(focusBtn, fl(cell * 0.74f, cell * 0.74f, cell * 0.13f, cell * 0.13f))
        focusTv = tvw("Focus", cell * 0.17f, Color.WHITE, true)
        focusPill.addView(focusTv, fl(cell * 0.9f, cell * 0.25f, cell * 1.0f, cell * 0.375f))
        focusPill.addView(icon(R.drawable.ic_chevron), fl(cell * 0.16f, cell * 0.16f, cell * 1.72f, cell * 0.42f))
        act(focusPill) { sys.toggleFocus(); hd.postDelayed({ refresh() }, 200) }
        lact(focusPill) { go { sys.openFocus() } }
        tiles["focus"] = focusPill

        torchBtn = ibtn(R.drawable.ic_flashlight).apply { onIconColor = Color.rgb(28, 28, 30) }
        act(torchBtn) { sys.setTorch(!sys.torchOn); torchBtn.setLit(sys.torchOn) }
        lact(torchBtn) { showTorchPopup(torchBtn) }
        tiles["torch"] = torchBtn

        val timer = ibtn(R.drawable.ic_timer).apply { setGlow(Color.rgb(255, 120, 30)) }
        act(timer) { showTimerCard() }
        lact(timer) { showTimerMenu(timer) }
        tiles["timer"] = timer

        val calc = ibtn(R.drawable.ic_calc)
        act(calc) { go { sys.openCalculator() } }
        tiles["calc"] = calc

        val cam = ibtn(R.drawable.ic_camera)
        act(cam) { go { sys.openCamera() } }
        tiles["cam"] = cam

        val mirror = ibtn(R.drawable.ic_mirror).apply { setGlow(Color.rgb(60, 110, 255)) }
        act(mirror) { go { sys.openCast() } }
        tiles["mirror"] = mirror

        val qr = ibtn(R.drawable.ic_qr).apply { setGlow(Color.rgb(120, 120, 200)) }
        act(qr) { go { sys.openQr() } }
        tiles["qr"] = qr

        val rec = ibtn(R.drawable.ic_record).apply { onIconColor = red }
        rec.setLit(true)
        act(rec) { go { sys.openRecorder { svc.screenshot() } } }
        tiles["rec"] = rec

        saverBtn = ibtn(R.drawable.ic_battery).apply { onIconColor = amber }
        act(saverBtn) { go { sys.openSaver() } }
        tiles["saver"] = saverBtn

        val dolby = ibtn(R.drawable.ic_dolby).apply { onIconColor = Color.rgb(0, 120, 255) }
        dolby.setLit(true)
        act(dolby) { go { sys.openSound() } }
        tiles["dolby"] = dolby

        val wp = ibtn(R.drawable.ic_wpower)
        act(wp) { go { sys.openSettings() } }
        tiles["wpower"] = wp
    }

    private fun buildConn(): View {
        val blk = FrameLayout(svc).apply { background = GlassDrawable(dn, cell * 0.5f) }
        fun put(id: String, cx: Float, cy: Float, d: Float, frac: Float) {
            val c = conns.first { it.id == id }
            val b = ibtn(c.icon, frac).apply { onFill = blue; onIconColor = Color.WHITE }
            blk.addView(b, fl(d * cell, d * cell, (cx - d / 2f) * cell, (cy - d / 2f) * cell))
            act(b) { connTap(id) }
            lact(b) { goPage(2) }
            blockBtns[id] = b
        }
        put("air", 0.59f, 0.59f, 0.82f, 0.46f)
        put("share", 1.62f, 0.60f, 0.82f, 0.46f)
        put("wifi", 0.59f, 1.62f, 0.82f, 0.46f)
        put("data", 1.40f, 1.43f, 0.36f, 0.55f)
        put("bt", 1.85f, 1.42f, 0.36f, 0.55f)
        put("hot", 1.40f, 1.87f, 0.36f, 0.55f)
        put("vpn", 1.85f, 1.87f, 0.36f, 0.55f)
        lact(blk) { goPage(2) }
        return blk
    }

    private fun buildMiniMedia(): View {
        val card = FrameLayout(svc).apply { background = GlassDrawable(dn, cell * 0.5f) }
        miniArt = ImageView(svc).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.argb(60, 255, 255, 255))
        }
        roundOutline(miniArt, cell * 0.2f)
        card.addView(miniArt, fl(cell * 0.71f, cell * 0.71f, cell * 0.19f, cell * 0.19f))
        val cast = ibtn(R.drawable.ic_share, 0.5f)
        cast.isClickable = false
        card.addView(cast, fl(cell * 0.4f, cell * 0.4f, cell * 1.51f, cell * 0.3f))
        miniTitle = tvw("Not Playing", cell * 0.155f, Color.WHITE, true)
        card.addView(miniTitle, fl(cell * 1.85f, cell * 0.22f, cell * 0.19f, cell * 1.05f))
        miniArtist = tvw("", cell * 0.14f, Color.argb(170, 255, 255, 255))
        card.addView(miniArtist, fl(cell * 1.85f, cell * 0.2f, cell * 0.19f, cell * 1.32f))
        val prev = icon(R.drawable.ic_prev)
        val next = icon(R.drawable.ic_next)
        miniPlay = icon(R.drawable.ic_play)
        card.addView(prev, fl(cell * 0.32f, cell * 0.32f, cell * 0.32f, cell * 1.72f))
        card.addView(miniPlay, fl(cell * 0.4f, cell * 0.4f, cell * 0.9f, cell * 1.68f))
        card.addView(next, fl(cell * 0.32f, cell * 0.32f, cell * 1.56f, cell * 1.72f))
        prev.setOnClickListener { if (!edit) { buzz(it); MediaHub.prev() } }
        next.setOnClickListener { if (!edit) { buzz(it); MediaHub.next() } }
        miniPlay.setOnClickListener { if (!edit) { buzz(it); MediaHub.toggle() } }
        act(card) { goPage(1) }
        lact(card) { goPage(1) }
        return card
    }

    private fun layoutGrid() {
        page0.removeAllViews()
        val hidden = Prefs.hidden(svc)
        val occ = Array(16) { BooleanArray(4) }
        for (s in specs) {
            if (hidden.contains(s.id)) continue
            val v = tiles[s.id] ?: continue
            var placed = false
            var r = 0
            while (!placed && r < 12) {
                for (c in 0..(4 - s.w)) {
                    var ok = true
                    for (rr in r until r + s.h) for (cc in c until c + s.w) if (occ[rr][cc]) ok = false
                    if (ok) {
                        for (rr in r until r + s.h) for (cc in c until c + s.w) occ[rr][cc] = true
                        val x = m + c * (cell + gap)
                        val y = gridTop + r * (cell + gap)
                        val w = s.w * cell + (s.w - 1) * gap
                        val hh = s.h * cell + (s.h - 1) * gap
                        (v.parent as? ViewGroup)?.removeView(v)
                        page0.addView(v, fl(w, hh, x, y))
                        if (edit) {
                            val bd = cell * 0.3f
                            page0.addView(badge(s.id), fl(bd, bd, x - bd * 0.25f, y - bd * 0.25f))
                        }
                        placed = true
                        break
                    }
                }
                r++
            }
        }
        if (!::addLabel.isInitialized) {
            addLabel = tvw("+  Add a Control", cell * 0.17f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                visibility = View.GONE
                setOnClickListener { showAddPopup() }
            }
            host.addView(addLabel, fl(cell * 2.2f, cell * 0.5f, (W - cell * 2.2f) / 2f, H * 0.93f - cell * 0.5f))
        }
    }

    private fun badge(id: String): View {
        val d = cell * 0.3f
        val iv = ImageView(svc)
        iv.setImageResource(R.drawable.ic_minus)
        iv.setColorFilter(Color.WHITE)
        val p = (d * 0.2f).toInt()
        iv.setPadding(p, p, p, p)
        iv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(235, 70, 70, 76))
            setStroke(max(1, dn.toInt()), Color.argb(120, 255, 255, 255))
        }
        iv.setOnClickListener {
            val hs = Prefs.hidden(svc)
            hs.add(id)
            Prefs.setHidden(svc, hs)
            layoutGrid()
            startJiggle()
        }
        return iv
    }

    // ---------------------------------------------------------------- edit mode
    private fun toggleEdit() { if (edit) exitEdit() else enterEdit() }

    private fun enterEdit() {
        edit = true
        sliderB.locked = true
        sliderV.locked = true
        plusBtn.visibility = View.GONE
        doneTv.visibility = View.VISIBLE
        addLabel.visibility = View.VISIBLE
        layoutGrid()
        startJiggle()
    }

    private fun exitEdit() {
        edit = false
        sliderB.locked = false
        sliderV.locked = false
        plusBtn.visibility = View.VISIBLE
        doneTv.visibility = View.GONE
        addLabel.visibility = View.GONE
        stopJiggle()
        layoutGrid()
    }

    private fun startJiggle() {
        stopJiggle()
        for ((_, v) in tiles) {
            if (v.parent == null) continue
            val a = ObjectAnimator.ofFloat(v, View.ROTATION, -1.7f, 1.7f)
            a.duration = (105 + rnd.nextInt(40)).toLong()
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.startDelay = rnd.nextInt(90).toLong()
            a.start()
            jiggles.add(a)
        }
    }

    private fun stopJiggle() {
        for (a in jiggles) a.cancel()
        jiggles.clear()
        for ((_, v) in tiles) v.rotation = 0f
    }

    private fun showAddPopup() {
        val hidden = Prefs.hidden(svc)
        val col = menuCard()
        val list = specs.filter { hidden.contains(it.id) }
        if (list.isEmpty()) {
            col.addView(menuRow(null, "All controls added") {})
        }
        for (s in list) {
            col.addView(menuRow(R.drawable.ic_plus, s.name) {
                val hs = Prefs.hidden(svc)
                hs.remove(s.id)
                Prefs.setHidden(svc, hs)
                closePopup()
                layoutGrid()
                startJiggle()
            })
        }
        showPopup(col, (W * 0.72f).toInt(), null, null, null, false)
    }

    // ---------------------------------------------------------------- connectivity logic
    private fun connOn(id: String): Boolean = when (id) {
        "air" -> sys.airplane()
        "share" -> true
        "wifi" -> sys.wifiOn()
        "data" -> sys.dataOn()
        "bt" -> sys.btOn()
        "hot" -> sys.hotspotOn()
        "vpn" -> sys.vpnOn()
        "nfc" -> sys.nfcOn()
        else -> false
    }

    private fun connSub(id: String): String = when (id) {
        "share" -> "Contacts Only"
        "wifi" -> if (!sys.wifiOn()) "Off" else (sys.ssid() ?: "On")
        "vpn" -> if (sys.vpnOn()) "Connected" else "Not Connected"
        else -> if (connOn(id)) "On" else "Off"
    }

    private fun connTap(id: String) {
        go {
            when (id) {
                "air" -> sys.openAirplane()
                "share" -> sys.openShare()
                "wifi" -> sys.openWifi()
                "data" -> sys.openData()
                "bt" -> sys.openBluetooth()
                "hot" -> sys.openHotspot()
                "vpn" -> sys.openVpn()
                "nfc" -> sys.openNfc()
            }
        }
    }

    private fun connLong(id: String, anchor: View) {
        val c = conns.first { it.id == id }
        val col = menuCard()
        val header = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(icon(c.icon), LinearLayout.LayoutParams((cell * 0.3f).toInt(), (cell * 0.3f).toInt()))
        header.addView(tvw(c.title, cell * 0.17f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.leftMargin = (cell * 0.15f).toInt() })
        val tg = ToggleView(svc).apply { checked = connOn(id); onToggle = { v -> go { connTap(id) }; checked = !v } }
        header.addView(tg, LinearLayout.LayoutParams((cell * 0.62f).toInt(), (cell * 0.38f).toInt()))
        col.addView(header, LinearLayout.LayoutParams(-1, (cell * 0.6f).toInt()))
        col.addView(tvw(connSub(id), cell * 0.14f, Color.argb(170, 255, 255, 255)), LinearLayout.LayoutParams(-1, (cell * 0.3f).toInt()))
        col.addView(menuRow(null, c.title + " Settings") { connTap(id) })
        showPopup(col, (W * 0.7f).toInt(), null, anchor, null, false)
    }

    // ---------------------------------------------------------------- list page (page 2)
    private fun buildListPage() {
        val rh = cell * 0.85f
        val rg = cell * 0.2f
        var y = gridTop + cell * 0.4f
        for (c in conns) {
            val row = FrameLayout(svc).apply {
                background = GlassDrawable(dn, -1f).also { it.darken = Color.argb(70, 30, 70, 170) }
            }
            val b = ibtn(c.icon, 0.5f).apply { isClickable = false; onFill = blue; onIconColor = Color.WHITE }
            row.addView(b, fl(rh * 0.78f, rh * 0.78f, rh * 0.11f, rh * 0.11f))
            row.addView(tvw(c.title, cell * 0.16f, Color.WHITE, true), fl(cw - rh * 1.2f, cell * 0.22f, rh * 1.0f, rh * 0.5f - cell * 0.22f))
            val sub = tvw("", cell * 0.125f, Color.argb(170, 255, 255, 255))
            row.addView(sub, fl(cw - rh * 1.2f, cell * 0.18f, rh * 1.0f, rh * 0.52f))
            act(row) { connTap(c.id) }
            lact(row) { connLong(c.id, row) }
            page2.addView(row, fl(cw, rh, m, y))
            rowBtns[c.id] = b
            rowSubs[c.id] = sub
            rowViews[c.id] = row
            y += rh + rg
        }
    }

    // ---------------------------------------------------------------- media page (page 1)
    private fun buildMediaPage() {
        val pad = cw * 0.075f
        val art = cw - 2f * pad
        val card = FrameLayout(svc).apply { background = GlassDrawable(dn, cw * 0.09f) }
        bigArt = ImageView(svc).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.argb(60, 255, 255, 255))
        }
        roundOutline(bigArt, cw * 0.06f)
        card.addView(bigArt, fl(art, art, pad, pad))
        var y = pad + art + cw * 0.04f
        bigTitle = tvw("Not Playing", cw * 0.05f, Color.WHITE, true)
        card.addView(bigTitle, fl(art, cw * 0.065f, pad, y))
        y += cw * 0.068f
        bigArtist = tvw("", cw * 0.045f, Color.argb(170, 255, 255, 255))
        card.addView(bigArtist, fl(art, cw * 0.06f, pad, y))
        y += cw * 0.1f
        bigSeek = SliderView(svc, false).apply {
            value = 0f
            onRelease = { v -> MediaHub.seek((v * MediaHub.duration()).toLong()) }
        }
        card.addView(bigSeek, fl(art, cw * 0.02f, pad, y))
        y += cw * 0.03f
        tPos = tvw("0:00", cw * 0.03f, Color.argb(150, 255, 255, 255))
        tLen = tvw("0:00", cw * 0.03f, Color.argb(150, 255, 255, 255)).apply { gravity = Gravity.END }
        card.addView(tPos, fl(art / 2f, cw * 0.04f, pad, y))
        card.addView(tLen, fl(art / 2f, cw * 0.04f, pad + art / 2f, y))
        y += cw * 0.075f
        val bs = cw * 0.1f
        val prev = icon(R.drawable.ic_prev)
        bigPlay = icon(R.drawable.ic_play)
        val next = icon(R.drawable.ic_next)
        val cx = cw / 2f
        card.addView(prev, fl(bs, bs, cx - cw * 0.27f - bs / 2f, y))
        card.addView(bigPlay, fl(bs * 1.3f, bs * 1.3f, cx - bs * 0.65f, y - bs * 0.15f))
        card.addView(next, fl(bs, bs, cx + cw * 0.27f - bs / 2f, y))
        prev.setOnClickListener { if (!edit) { buzz(it); MediaHub.prev() } }
        next.setOnClickListener { if (!edit) { buzz(it); MediaHub.next() } }
        bigPlay.setOnClickListener { if (!edit) { buzz(it); MediaHub.toggle() } }
        y += bs * 1.25f
        bigVol = SliderView(svc, false).apply {
            value = sys.volume()
            onChange = { v -> sys.setVolume(v) }
        }
        card.addView(bigVol, fl(art, cw * 0.025f, pad, y))
        y += cw * 0.065f
        val chip = tvw("This Phone", cw * 0.034f, Color.argb(200, 255, 255, 255)).apply { gravity = Gravity.CENTER }
        card.addView(chip, fl(art, cw * 0.045f, pad, y))
        y += cw * 0.045f + pad
        page1.addView(card, fl(cw, y, m, H * 0.17f))
        val pill = FrameLayout(svc).apply { background = GlassDrawable(dn) }
        val pt = tvw("Control Other Speakers & TVs", cw * 0.036f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        pill.addView(pt, fl(cw * 0.6f, cw * 0.1f, cw * 0.1f, 0f))
        pill.addView(icon(R.drawable.ic_mirror), fl(cw * 0.06f, cw * 0.06f, cw * 0.06f, cw * 0.02f))
        act(pill) { go { sys.openCast() } }
        page1.addView(pill, fl(cw * 0.72f, cw * 0.1f, (W - cw * 0.72f) / 2f, H * 0.17f + y + cw * 0.06f))
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt().coerceAtLeast(0)
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun setArt(iv: ImageView, b: Bitmap?) {
        if (b != null) { iv.setImageBitmap(b); iv.setColorFilter(null) }
        else { iv.setImageResource(R.drawable.ic_music); iv.setColorFilter(Color.argb(160, 255, 255, 255)); iv.scaleType = ImageView.ScaleType.CENTER_INSIDE }
        if (b != null) iv.scaleType = ImageView.ScaleType.CENTER_CROP
    }

    private fun refreshMedia() {
        val t = MediaHub.title()
        val a = MediaHub.artist()
        miniTitle.text = t
        miniArtist.text = a
        bigTitle.text = t
        bigArtist.text = a
        val bmp = MediaHub.art()
        setArt(miniArt, bmp)
        setArt(bigArt, bmp)
        val res = if (MediaHub.playing()) R.drawable.ic_pause else R.drawable.ic_play
        miniPlay.setImageResource(res)
        bigPlay.setImageResource(res)
        refreshMediaProgress()
    }

    private fun refreshMediaProgress() {
        if (pageF < 0.5f || pageF > 1.5f) return
        val d = MediaHub.duration()
        val p = MediaHub.position()
        if (d > 0) bigSeek.value = p.toFloat() / d
        tPos.text = fmt(p)
        tLen.text = "-" + fmt(max(0L, d - p))
    }

    // ---------------------------------------------------------------- state refresh
    private fun refresh() {
        for (c in conns) {
            val on = connOn(c.id)
            blockBtns[c.id]?.setLit(on)
            rowBtns[c.id]?.setLit(on)
            rowSubs[c.id]?.text = connSub(c.id)
        }
        orientBtn.setLit(sys.rotationLocked())
        val silent = sys.silent()
        bellBtn.setIcon(if (silent) R.drawable.ic_bell_off else R.drawable.ic_bell)
        bellBtn.setLit(silent)
        torchBtn.setLit(sys.torchOn)
        saverBtn.setLit(sys.saverOn())
        val f = sys.focusOn()
        focusBtn.setLit(f)
        focusTv.text = if (f) "On" else "Focus"
        if (!sliderB.touching) sliderB.value = sys.brightness()
        sliderV.setIcon(if (sys.volume() <= 0.001f) R.drawable.ic_volume_off else R.drawable.ic_volume)
        if (!sliderV.touching) sliderV.value = sys.volume()
        carrierTv.text = sys.carrier()
        val b = sys.battery()
        battTv.text = b.pct.toString() + "%"
        battView.pct = b.pct
        battView.charging = b.charging
        battView.saver = sys.saverOn()
        battView.invalidate()
        rotIcon.visibility = if (sys.rotationLocked()) View.VISIBLE else View.INVISIBLE
        bigVol.value = sys.volume()
    }

    // ---------------------------------------------------------------- pages
    private fun setPageF(f: Float) {
        pageF = f
        for (i in pageList.indices) {
            val d = i - f
            val p = pageList[i]
            val a = (1f - abs(d)).coerceIn(0f, 1f)
            p.alpha = a
            p.translationY = d * H * 0.16f
            val s = 1f - 0.05f * min(1f, abs(d))
            p.scaleX = s
            p.scaleY = s
            p.visibility = if (a < 0.01f) View.INVISIBLE else View.VISIBLE
        }
        val cur = f.roundToInt().coerceIn(0, 2)
        for (i in indicators.indices) indicators[i].alpha = if (i == cur) 1f else 0.4f
    }

    private fun goPage(i: Int) {
        pageAnim?.cancel()
        val from = pageF
        pageAnim = ValueAnimator.ofFloat(from, i.toFloat()).apply {
            duration = 480
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener { setPageF(it.animatedValue as Float) }
            start()
        }
    }

    // ---------------------------------------------------------------- open / close
    fun setProgress(p: Float) {
        progress = p
        setBackgroundColor(Color.argb((p * 105).toInt(), 6, 8, 18))
        host.alpha = p
        val s = 1.08f - 0.08f * p
        host.scaleX = s
        host.scaleY = s
        host.translationY = -(1f - p) * dp(26f)
        blurSetter?.invoke((p * 70f).toInt())
    }

    private fun animateProgress(to: Float, dur: Long, interp: android.animation.TimeInterpolator, end: (() -> Unit)?) {
        progAnim?.cancel()
        progAnim = ValueAnimator.ofFloat(progress, to).apply {
            duration = dur
            interpolator = interp
            addUpdateListener { setProgress(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) end?.invoke() }
            })
            start()
        }
    }

    fun openAnimated() {
        refresh()
        refreshMedia()
        animateProgress(1f, 460, DecelerateInterpolator(1.6f), null)
        popTiles()
        startTicker()
    }

    fun settleOpen() {
        animateProgress(1f, 260, DecelerateInterpolator(1.4f), null)
        popTiles()
        startTicker()
    }

    fun cancelOpen(done: () -> Unit) {
        animateProgress(0f, 180, AccelerateInterpolator(), done)
    }

    fun closeAnimated(done: () -> Unit) {
        if (popup != null) closePopupNow()
        animateProgress(0f, 240, AccelerateInterpolator(1.2f), done)
    }

    private fun startTicker() {
        hd.removeCallbacks(ticker)
        hd.postDelayed(ticker, 500)
    }

    private fun popTiles() {
        var i = 0
        for (k in 0 until page0.childCount) {
            val v = page0.getChildAt(k)
            v.scaleX = 0.78f
            v.scaleY = 0.78f
            v.alpha = 0f
            v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setStartDelay((i * 18).toLong()).setDuration(440)
                .setInterpolator(OvershootInterpolator(1.5f)).start()
            i++
        }
    }

    fun release() {
        hd.removeCallbacksAndMessages(null)
        MediaHub.removeListener(mediaListener)
        progAnim?.cancel()
        pageAnim?.cancel()
        blurAnim?.cancel()
        stopJiggle()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_UP) {
                if (popup != null) closePopup() else if (edit) exitEdit() else closeRequest?.invoke()
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------------------------------------------------------------- touch: page swipes, tap outside to close
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> beginTrack(e)
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!dragging && popup == null && !edit) {
                    val dy = e.y - dY
                    val dx = e.x - dX
                    if (abs(dy) > slop && abs(dy) > abs(dx) * 1.3f) {
                        dragging = true
                        pageAnim?.cancel()
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun beginTrack(e: MotionEvent) {
        dX = e.x
        dY = e.y
        dragging = false
        startPageF = pageF.roundToInt().toFloat()
        vt?.recycle()
        vt = VelocityTracker.obtain()
        vt?.addMovement(e)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> beginTrack(e)
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!dragging && popup == null && !edit) {
                    val dy = e.y - dY
                    if (abs(dy) > slop && abs(dy) > abs(e.x - dX) * 1.3f) { dragging = true; pageAnim?.cancel() }
                }
                if (dragging) setPageF((startPageF - (e.y - dY) / (H * 0.5f)).coerceIn(-0.2f, 2.25f))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle()
                vt = null
                if (dragging) {
                    dragging = false
                    val delta = pageF - startPageF
                    val sp = startPageF.toInt()
                    val target = when {
                        delta > 0.18f || vy < -900f -> sp + 1
                        delta < -0.18f || vy > 900f -> sp - 1
                        else -> sp
                    }
                    if (target > 2) { closeRequest?.invoke(); setPageF(2f) }
                    else goPage(target.coerceAtLeast(0))
                } else if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.x - dX) < slop && abs(e.y - dY) < slop) {
                    if (edit) exitEdit() else if (popup == null) closeRequest?.invoke()
                }
            }
        }
        return true
    }

    // ---------------------------------------------------------------- popups
    private fun anchorRect(v: View): RectF {
        val l = IntArray(2)
        v.getLocationInWindow(l)
        return RectF(l[0].toFloat(), l[1].toFloat(), l[0] + v.width.toFloat(), l[1] + v.height.toFloat())
    }

    private fun menuCard(): LinearLayout = LinearLayout(svc).apply {
        orientation = LinearLayout.VERTICAL
        val p = (cell * 0.2f).toInt()
        setPadding(p, p, p, p)
        background = GlassDrawable(dn, cell * 0.5f).also { it.darken = Color.argb(110, 24, 26, 40) }
    }

    private fun menuRow(res: Int?, text: String, onClick: () -> Unit): View {
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (res != null) row.addView(icon(res), LinearLayout.LayoutParams((cell * 0.26f).toInt(), (cell * 0.26f).toInt()).also { it.rightMargin = (cell * 0.18f).toInt() })
        row.addView(tvw(text, cell * 0.17f, Color.WHITE, false))
        row.layoutParams = LinearLayout.LayoutParams(-1, (cell * 0.56f).toInt())
        row.setOnClickListener { buzz(it); onClick() }
        return row
    }

    private fun showPopup(card: View, w: Int, fixedH: Int?, anchor: View?, topY: Float?, fromTop: Boolean) {
        closePopupNow()
        val layer = FrameLayout(svc)
        layer.isClickable = true
        layer.setOnClickListener { closePopup() }
        val ch = fixedH ?: run {
            card.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            card.measuredHeight
        }
        val x = (W - w) / 2f
        val y = topY ?: ((H - ch) / 2f)
        card.isClickable = true
        layer.addView(card, fl(w.toFloat(), ch.toFloat(), x, y))
        addView(layer, FrameLayout.LayoutParams(-1, -1))
        popup = layer
        card.pivotX = w / 2f
        card.pivotY = ch / 2f
        val a = anchor?.let { anchorRect(it) }
        var s0 = 0.8f
        var tx = 0f
        var ty = 0f
        if (a != null) {
            s0 = (a.width() / w).coerceIn(0.25f, 0.9f)
            tx = a.centerX() - (x + w / 2f)
            ty = a.centerY() - (y + ch / 2f)
        } else if (fromTop) {
            s0 = 0.92f
            ty = -(y + ch)
        }
        card.scaleX = s0
        card.scaleY = s0
        card.translationX = tx
        card.translationY = ty
        card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).alpha(1f)
            .setDuration(460).setInterpolator(OvershootInterpolator(1.0f)).start()
        layer.setBackgroundColor(Color.argb(0, 0, 0, 0))
        ValueAnimator.ofInt(0, 100).apply {
            duration = 300
            addUpdateListener { layer.setBackgroundColor(Color.argb(it.animatedValue as Int, 0, 0, 0)) }
            start()
        }
        blurBackground(true)
    }

    private fun closePopup() {
        val layer = popup ?: return
        popup = null
        blurBackground(false)
        val card = if (layer.childCount > 0) layer.getChildAt(0) else null
        card?.animate()?.scaleX(0.85f)?.scaleY(0.85f)?.alpha(0f)?.setDuration(170)?.start()
        layer.animate().alpha(0f).setDuration(190).withEndAction { removeView(layer) }.start()
    }

    private fun closePopupNow() {
        val layer = popup ?: return
        popup = null
        removeView(layer)
        blurAnim?.cancel()
        blurNow = 0f
        if (Build.VERSION.SDK_INT >= 31) host.setRenderEffect(null)
    }

    private fun blurBackground(on: Boolean) {
        if (Build.VERSION.SDK_INT < 31) return
        blurAnim?.cancel()
        blurAnim = ValueAnimator.ofFloat(blurNow, if (on) 26f else 0f).apply {
            duration = 320
            addUpdateListener {
                blurNow = it.animatedValue as Float
                if (blurNow < 0.5f) host.setRenderEffect(null)
                else host.setRenderEffect(RenderEffect.createBlurEffect(blurNow, blurNow, Shader.TileMode.CLAMP))
            }
            start()
        }
    }

    private fun showOrientPopup(anchor: View) {
        val w = (W * 0.6f).toInt()
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            val p = (cell * 0.25f).toInt()
            setPadding(p, p, p, p)
            background = GlassDrawable(dn, cell * 0.55f).also { it.darken = Color.argb(110, 24, 26, 40) }
        }
        val big = ibtn(R.drawable.ic_lock_rotate, 0.5f).apply { onIconColor = red; isClickable = false; setLit(sys.rotationLocked()) }
        col.addView(big, LinearLayout.LayoutParams((cell * 0.85f).toInt(), (cell * 0.85f).toInt()))
        col.addView(tvw("Orientation Lock", cell * 0.19f, Color.WHITE, true), LinearLayout.LayoutParams(-2, -2).also { it.topMargin = (cell * 0.12f).toInt() })
        val st = tvw(if (sys.rotationLocked()) "On" else "Off", cell * 0.15f, Color.argb(170, 255, 255, 255))
        col.addView(st, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = (cell * 0.04f).toInt() })
        val tg = ToggleView(svc).apply {
            checked = sys.rotationLocked()
            onToggle = {
                sys.toggleRotation()
                hd.postDelayed({
                    big.setLit(sys.rotationLocked())
                    st.text = if (sys.rotationLocked()) "On" else "Off"
                    refresh()
                }, 150)
            }
        }
        col.addView(tg, LinearLayout.LayoutParams((cell * 0.7f).toInt(), (cell * 0.42f).toInt()).also { it.topMargin = (cell * 0.2f).toInt() })
        val ds = tvw("Display Settings", cell * 0.17f, Color.WHITE, false)
        ds.setOnClickListener { go { sys.openDisplay() } }
        col.addView(ds, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = (cell * 0.3f).toInt() })
        showPopup(col, w, null, anchor, null, false)
    }

    private fun showTorchPopup(anchor: View) {
        val w = (W * 0.34f).toInt()
        val h = (H * 0.43f).toInt()
        val s = SliderView(svc).apply {
            setIcon(R.drawable.ic_flashlight)
            iconColor = Color.rgb(28, 28, 30)
            scaleOnTouch = 1.03f
            value = if (sys.torchOn) sys.torchLevel / max(1f, sys.torchMax.toFloat()) else 0f
            onChange = { v ->
                if (v < 0.04f) sys.setTorch(false)
                else sys.setTorch(true, max(1, ceil(v * sys.torchMax).toInt()))
            }
            onRelease = { torchBtn.setLit(sys.torchOn) }
        }
        showPopup(s, w, h, anchor, null, false)
    }

    private fun showTimerMenu(anchor: View) {
        val col = menuCard()
        col.addView(menuRow(R.drawable.ic_timer, "Start Timer") { go { sys.startTimer(60) } })
        col.addView(menuRow(R.drawable.ic_timer, "Start Stopwatch") { go { sys.openStopwatch() } })
        col.addView(menuRow(R.drawable.ic_bell, "Create Alarm") { go { sys.openAlarm() } })
        showPopup(col, (W * 0.62f).toInt(), null, anchor, null, false)
    }

    private fun showTimerCard() {
        val orange = Color.rgb(255, 159, 10)
        val w = (W - dp(24f)).toInt()
        val h = (cell * 2.3f).toInt()
        val card = FrameLayout(svc)
        card.background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = cell * 0.62f }
        val ruler = RulerView(svc)
        card.addView(ruler, fl(w - cell * 0.5f, h * 0.46f, cell * 0.25f, cell * 0.1f))
        val time = tvw("2:00", cell * 0.62f, orange, false).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        card.addView(time, fl(w * 0.55f, cell * 0.8f, w * 0.45f - cell * 0.3f, h * 0.55f))
        val start = tvw("Start", cell * 0.19f, orange, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.argb(60, 255, 159, 10)); cornerRadius = cell }
        }
        card.addView(start, fl(cell * 0.95f, cell * 0.5f, cell * 0.3f, h * 0.55f + cell * 0.15f))
        fun label(min: Float): String {
            val t = min.toInt()
            return if (t < 60) "$t:00" else (t / 60).toString() + ":" + (t % 60).toString().padStart(2, '0') + ":00"
        }
        ruler.minutes = 2f
        ruler.onChange = { time.text = label(it) }
        start.setOnClickListener {
            val sec = max(1, ruler.minutes.toInt()) * 60
            go { sys.startTimer(sec) }
        }
        showPopup(card, w, h, null, H * 0.012f, true)
    }
}
