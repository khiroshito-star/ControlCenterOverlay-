package app.glasscenter

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.max
import kotlin.math.min

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("gc", Context.MODE_PRIVATE)
    fun widthPct(c: Context): Int = sp(c).getInt("w", 60)
    fun heightDp(c: Context): Int = sp(c).getInt("h", 28)
    fun position(c: Context): Int = sp(c).getInt("pos", 1) // 0 left, 1 center, 2 right
    fun haptics(c: Context): Boolean = sp(c).getBoolean("hap", true)
    fun set(c: Context, key: String, v: Int) { sp(c).edit().putInt(key, v).apply() }
    fun setHaptics(c: Context, v: Boolean) { sp(c).edit().putBoolean("hap", v).apply() }
    fun hidden(c: Context): MutableSet<String> {
        val s = sp(c).getStringSet("hidden", null) ?: return HashSet()
        return HashSet(s)
    }
    fun setHidden(c: Context, s: Set<String>) { sp(c).edit().putStringSet("hidden", HashSet(s)).apply() }
}

/** Frosted "liquid glass" surface: translucent gradient, soft specular highlight and a bright rim. */
class GlassDrawable(
    private val density: Float,
    var radius: Float = -1f,
    fill: Int = 0,
    glow: Int = 0
) : Drawable() {
    var fill: Int = fill
        set(v) { field = v; invalidateSelf() }
    var glow: Int = glow
        set(v) { field = v; dirty = true; invalidateSelf() }
    var darken: Int = 0
        set(v) { field = v; invalidateSelf() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val s = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private var base: Shader? = null
    private var spec: Shader? = null
    private var rim: Shader? = null
    private var glowSh: Shader? = null
    private var dirty = true

    override fun onBoundsChange(bounds: Rect) {
        dirty = true
    }

    private fun build() {
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat()
        val r = b.right.toFloat(); val bt = b.bottom.toFloat()
        val w = max(1f, r - l); val h = max(1f, bt - t)
        base = LinearGradient(l, t, l, bt, Color.argb(78, 255, 255, 255), Color.argb(34, 255, 255, 255), Shader.TileMode.CLAMP)
        spec = RadialGradient(l + w * 0.3f, t + h * 0.12f, max(w, h) * 0.75f,
            Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        rim = LinearGradient(l, t, r, bt,
            intArrayOf(Color.argb(200, 255, 255, 255), Color.argb(26, 255, 255, 255), Color.argb(26, 255, 255, 255), Color.argb(150, 255, 255, 255)),
            floatArrayOf(0f, 0.4f, 0.6f, 1f), Shader.TileMode.CLAMP)
        glowSh = if (glow != 0) RadialGradient(l + w * 0.8f, t + h * 0.85f, max(w, h) * 0.65f,
            Color.argb(170, Color.red(glow), Color.green(glow), Color.blue(glow)),
            Color.argb(0, Color.red(glow), Color.green(glow), Color.blue(glow)), Shader.TileMode.CLAMP) else null
        dirty = false
    }

    override fun draw(c: Canvas) {
        if (bounds.isEmpty) return
        if (dirty) build()
        val sw = 1.2f * density
        rect.set(bounds.left + sw / 2f, bounds.top + sw / 2f, bounds.right - sw / 2f, bounds.bottom - sw / 2f)
        val rad = if (radius < 0f) min(rect.width(), rect.height()) / 2f else radius
        if (fill != 0) {
            p.shader = null
            p.color = fill
            c.drawRoundRect(rect, rad, rad, p)
        } else {
            if (darken != 0) {
                p.shader = null
                p.color = darken
                c.drawRoundRect(rect, rad, rad, p)
            }
            p.shader = base
            c.drawRoundRect(rect, rad, rad, p)
            val g = glowSh
            if (g != null) {
                p.shader = g
                c.drawRoundRect(rect, rad, rad, p)
            }
            p.shader = spec
            c.drawRoundRect(rect, rad, rad, p)
        }
        s.strokeWidth = sw
        s.shader = rim
        c.drawRoundRect(rect, rad, rad, s)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Round (or pill) glass button with an icon. Lights up white/colored when "lit". */
class IconButton(ctx: Context) : View(ctx) {
    val glass = GlassDrawable(ctx.resources.displayMetrics.density)
    private var icon: Drawable? = null
    var onFill: Int = Color.WHITE
    var onIconColor: Int = Color.BLACK
    var offIconColor: Int = Color.WHITE
    var iconFrac: Float = 0.48f
    var lit: Boolean = false
        private set

    init {
        background = glass
        isClickable = true
    }

    fun setIcon(res: Int) {
        icon = context.getDrawable(res)?.mutate()
        applyColor()
        invalidate()
    }

    fun setGlow(c: Int) { glass.glow = c }

    fun setLit(on: Boolean) {
        lit = on
        glass.fill = if (on) onFill else 0
        applyColor()
        invalidate()
    }

    private fun applyColor() {
        icon?.setTint(if (lit) onIconColor else offIconColor)
    }

    override fun onDraw(canvas: Canvas) {
        val d = icon ?: return
        val sz = (min(width, height) * iconFrac).toInt()
        val l = (width - sz) / 2
        val t = (height - sz) / 2
        d.setBounds(l, t, l + sz, t + sz)
        d.draw(canvas)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(110).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(3f)).start()
        }
        return super.onTouchEvent(e)
    }
}

/** Vertical or horizontal pill slider (brightness, volume, torch strength, seek bar). */
class SliderView(ctx: Context, private val vertical: Boolean = true) : View(ctx) {
    private val glass = GlassDrawable(ctx.resources.displayMetrics.density)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(245, 255, 255, 255) }
    private val clip = Path()
    private var icon: Drawable? = null
    var iconColor: Int = Color.BLACK
    var iconOffColor: Int = Color.WHITE
    var locked = false
    var touching = false
    var scaleOnTouch = 1.06f
    var onChange: ((Float) -> Unit)? = null
    var onRelease: ((Float) -> Unit)? = null
    var value: Float = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    init {
        background = glass
        isClickable = true
    }

    fun setIcon(res: Int) {
        icon = context.getDrawable(res)?.mutate()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        clip.reset()
        val r = min(w, h) / 2f
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        c.save()
        c.clipPath(clip)
        if (vertical) c.drawRect(0f, height * (1f - value), width.toFloat(), height.toFloat(), fillPaint)
        else c.drawRect(0f, 0f, width * value, height.toFloat(), fillPaint)
        c.restore()
        val d = icon ?: return
        if (vertical) {
            val sz = (width * 0.44f).toInt()
            val cx = width / 2
            val cy = (height - width * 0.62f).toInt()
            d.setTint(if (height - cy < height * value) iconColor else iconOffColor)
            d.setBounds(cx - sz / 2, cy - sz / 2, cx + sz / 2, cy + sz / 2)
            d.draw(c)
        }
    }

    private fun update(e: MotionEvent) {
        val v = if (vertical) 1f - e.y / max(1, height) else e.x / max(1, width)
        value = v
        onChange?.invoke(value)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                parent?.requestDisallowInterceptTouchEvent(true)
                animate().scaleX(scaleOnTouch).scaleY(scaleOnTouch).setDuration(160).setInterpolator(DecelerateInterpolator()).start()
                update(e)
            }
            MotionEvent.ACTION_MOVE -> update(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(2.5f)).start()
                onRelease?.invoke(value)
            }
        }
        return true
    }
}

/** iOS style green switch. */
class ToggleView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pos = 0f
    var onToggle: ((Boolean) -> Unit)? = null
    var checked = false
        set(v) { field = v; pos = if (v) 1f else 0f; invalidate() }

    init {
        isClickable = true
        setOnClickListener {
            checked = !checked
            val from = if (checked) 0f else 1f
            pos = from
            ValueAnimator.ofFloat(from, if (checked) 1f else 0f).apply {
                duration = 220
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                start()
            }
            onToggle?.invoke(checked)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val off = Color.argb(90, 255, 255, 255)
        val on = Color.rgb(52, 199, 89)
        p.color = blend(off, on, pos)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        val r = h / 2f - h * 0.08f
        val cx = h / 2f + (w - h) * pos
        c.drawCircle(cx, h / 2f, r, p)
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}

/** Horizontal ruler used by the timer card. */
class RulerView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orange = Color.rgb(255, 159, 10)
    var minutes = 2f
        set(v) { field = v.coerceIn(0f, 180f); invalidate() }
    var onChange: ((Float) -> Unit)? = null
    private var lastX = 0f

    override fun onDraw(c: Canvas) {
        val spacing = context.dp(9f)
        val cx = width / 2f
        val first = (minutes - cx / spacing).toInt() - 1
        val last = (minutes + cx / spacing).toInt() + 1
        p.textSize = context.dp(11f)
        p.textAlign = Paint.Align.CENTER
        for (m in max(0, first)..min(180, last)) {
            val x = cx + (m - minutes) * spacing
            val major = m % 5 == 0
            p.color = if (major) orange else Color.argb(150, 255, 160, 10)
            p.strokeWidth = context.dp(1.4f)
            val len = if (major) height * 0.42f else height * 0.30f
            c.drawLine(x, height * 0.30f, x, height * 0.30f + len, p)
            if (major) {
                p.style = Paint.Style.FILL
                c.drawText(m.toString(), x, height * 0.22f, p)
            }
        }
        p.color = orange
        val tri = Path()
        tri.moveTo(cx, height * 0.78f)
        tri.lineTo(cx - context.dp(5f), height.toFloat())
        tri.lineTo(cx + context.dp(5f), height.toFloat())
        tri.close()
        c.drawPath(tri, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                lastX = e.x
                minutes = minutes - dx / context.dp(9f)
                onChange?.invoke(minutes)
            }
        }
        return true
    }
}
