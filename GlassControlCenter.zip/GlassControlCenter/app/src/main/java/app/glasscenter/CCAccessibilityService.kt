package app.glasscenter

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class CCAccessibilityService : AccessibilityService() {

    companion object {
        var instance: CCAccessibilityService? = null
    }

    lateinit var sys: Sys
    private lateinit var wm: WindowManager
    private var trigger: View? = null
    private var panel: ControlCenterView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var lastBlur = -1
    private var closing = false
    private val main = Handler(Looper.getMainLooper())

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            closePanel(false)
        }
    }

    override fun onServiceConnected() {
        instance = this
        sys = Sys(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF)) } catch (e: Exception) {}
        MediaHub.attach(applicationContext)
        addTrigger()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closePanel(false)
        rebuildTrigger()
    }

    override fun onDestroy() {
        instance = null
        closePanel(false)
        trigger?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        trigger = null
        try { unregisterReceiver(screenOff) } catch (e: Exception) {}
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    fun realSize(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    // ---- trigger strip -----------------------------------------------------------------------
    fun rebuildTrigger() {
        trigger?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        trigger = null
        addTrigger()
    }

    private fun addTrigger() {
        val v = TriggerView(this)
        val size = realSize()
        val w = (size.x * Prefs.widthPct(this) / 100f).toInt()
        val h = dp(Prefs.heightDp(this).toFloat()).toInt()
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val horizontal = when (Prefs.position(this)) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        lp.gravity = Gravity.TOP or horizontal
        try {
            wm.addView(v, lp)
            trigger = v
        } catch (e: Exception) {
        }
    }

    private inner class TriggerView(c: Context) : View(c) {
        private var downY = 0f
        private var tracking = false
        private var vt: VelocityTracker? = null

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    tracking = false
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    val dy = e.rawY - downY
                    if (!tracking && dy > dp(10f)) tracking = addPanel()
                    if (tracking) panel?.setProgress((dy / dp(260f)).coerceIn(0f, 1f))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.computeCurrentVelocity(1000)
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle()
                    vt = null
                    if (tracking) {
                        val p = panel
                        if (p != null) {
                            if (p.progress > 0.3f || vy > 1200f) p.settleOpen() else p.cancelOpen { removePanel() }
                        }
                        tracking = false
                    }
                }
            }
            return true
        }
    }

    // ---- panel window -----------------------------------------------------------------------
    @Suppress("DEPRECATION")
    private fun addPanel(): Boolean {
        if (panel != null) return false
        val p = ControlCenterView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lastBlur = -1
        p.blurSetter = { r -> setBlur(r) }
        p.closeRequest = { closePanel(true) }
        return try {
            wm.addView(p, lp)
            panel = p
            panelLp = lp
            closing = false
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun setBlur(r: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        val p = panel ?: return
        val lp = panelLp ?: return
        if (r == lastBlur) return
        lastBlur = r
        lp.blurBehindRadius = r
        try { wm.updateViewLayout(p, lp) } catch (e: Exception) {}
    }

    private fun removePanel() {
        val p = panel ?: return
        try { wm.removeView(p) } catch (e: Exception) {}
        p.release()
        panel = null
        panelLp = null
        closing = false
    }

    fun isPanelOpen(): Boolean = panel != null

    fun openPanel() {
        if (panel != null) return
        if (addPanel()) panel?.openAnimated()
    }

    fun closePanel(animate: Boolean) {
        val p = panel ?: return
        if (!animate) { removePanel(); return }
        if (closing) return
        closing = true
        p.closeAnimated { removePanel() }
    }

    fun power() { performGlobalAction(GLOBAL_ACTION_POWER_DIALOG) }

    fun screenshot() {
        closePanel(true)
        main.postDelayed({
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }, 450)
    }
}
