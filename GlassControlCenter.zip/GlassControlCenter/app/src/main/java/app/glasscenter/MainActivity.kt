package app.glasscenter

import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private val statusViews = ArrayList<() -> Unit>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.rgb(10, 11, 18))
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val p = dp(20)
        root.setPadding(p, dp(36), p, dp(40))
        sv.addView(root)
        setContentView(sv)
        build()
    }

    override fun onResume() {
        super.onResume()
        for (r in statusViews) r()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(16)
        setPadding(p, p, p, p)
        background = GradientDrawable().apply { setColor(Color.argb(255, 26, 28, 42)); cornerRadius = dp(18).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(12) }
    }

    private fun build() {
        root.addView(text("Glass Control Center", 26f, Color.WHITE, true))
        root.addView(text("An iOS-style Control Center overlay. It never replaces the system one.", 14f, Color.argb(170, 255, 255, 255)))

        root.addView(text("Permissions", 18f, Color.WHITE, true))
        permission(
            "Accessibility (required)",
            "Draws the overlay over every app and detects the swipe on the top strip. On Android 13+, if the toggle is greyed out: App info > ⋮ > Allow restricted settings.",
            { isAccessibilityOn() }
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        permission(
            "Modify system settings",
            "Lets the brightness slider, auto-rotate lock and similar controls change real settings.",
            { Settings.System.canWrite(this) }
        ) { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        permission(
            "Notification access",
            "Lets the media card show the song, artwork and play/pause/skip controls.",
            { isListenerOn() }
        ) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        permission(
            "Do Not Disturb access",
            "Needed for the Focus button and the silent-mode bell.",
            { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }
        ) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }

        root.addView(text("Trigger strip", 18f, Color.WHITE, true).apply { setPadding(0, dp(22), 0, 0) })
        val c = card()
        c.addView(text("Swipe down on the invisible strip at the top of the screen.", 13f, Color.argb(170, 255, 255, 255)))
        c.addView(seek("Width", 30, 100, Prefs.widthPct(this), "%") { Prefs.set(this, "w", it); CCAccessibilityService.instance?.rebuildTrigger() })
        c.addView(seek("Height", 12, 80, Prefs.heightDp(this), "dp") { Prefs.set(this, "h", it); CCAccessibilityService.instance?.rebuildTrigger() })
        val pos = LinearLayout(this)
        pos.orientation = LinearLayout.HORIZONTAL
        pos.setPadding(0, dp(10), 0, 0)
        val names = arrayOf("Left", "Center", "Right")
        val btns = ArrayList<Button>()
        for (i in 0..2) {
            val bt = Button(this)
            bt.text = names[i]
            bt.isAllCaps = false
            bt.setOnClickListener {
                Prefs.set(this, "pos", i)
                CCAccessibilityService.instance?.rebuildTrigger()
                for (k in 0..2) btns[k].alpha = if (k == i) 1f else 0.45f
            }
            bt.alpha = if (Prefs.position(this) == i) 1f else 0.45f
            btns.add(bt)
            pos.addView(bt, LinearLayout.LayoutParams(0, -2, 1f))
        }
        c.addView(pos)
        val hap = Switch(this)
        hap.text = "Haptic feedback"
        hap.setTextColor(Color.WHITE)
        hap.isChecked = Prefs.haptics(this)
        hap.setOnCheckedChangeListener { _, v -> Prefs.setHaptics(this, v) }
        hap.setPadding(0, dp(10), 0, 0)
        c.addView(hap)
        root.addView(c)

        val test = Button(this)
        test.text = "Open Control Center now"
        test.isAllCaps = false
        test.setOnClickListener {
            val s = CCAccessibilityService.instance
            if (s == null) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) else s.openPanel()
        }
        root.addView(test, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(18) })

        root.addView(text(
            "Notes: Wi-Fi, Bluetooth, mobile data, airplane mode, hotspot, NFC and VPN show their live state; tapping them opens the system panel because Android no longer lets normal apps flip those switches. Brightness, volume, rotation lock, silent mode, Focus and the flashlight (with strength slider) change directly. Long-press any control for its expanded view, and use + to edit.",
            12f, Color.argb(140, 255, 255, 255)).apply { setPadding(0, dp(16), 0, 0) })
    }

    private fun permission(title: String, desc: String, ok: () -> Boolean, open: () -> Unit) {
        val c = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 15f, Color.WHITE, true))
        val st = text("", 12f, Color.argb(170, 255, 255, 255))
        col.addView(st)
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        val bt = Button(this)
        bt.isAllCaps = false
        bt.setOnClickListener { open() }
        row.addView(bt)
        c.addView(row)
        c.addView(text(desc, 12f, Color.argb(140, 255, 255, 255)).apply { setPadding(0, dp(8), 0, 0) })
        root.addView(c)
        val upd = {
            val on = ok()
            st.text = if (on) "Enabled" else "Not enabled"
            st.setTextColor(if (on) Color.rgb(52, 199, 89) else Color.rgb(255, 159, 10))
            bt.text = if (on) "Manage" else "Grant"
        }
        statusViews.add(upd)
        upd()
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, unit: String, onSet: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(10), 0, 0)
        val t = text("$label: $cur$unit", 13f, Color.WHITE)
        box.addView(t)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                t.text = "$label: ${p + min}$unit"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onSet((s?.progress ?: 0) + min) }
        })
        box.addView(sb)
        return box
    }

    private fun isAccessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, CCAccessibilityService::class.java).flattenToString()
        return s.split(':').any { it.equals(me, true) }
    }

    private fun isListenerOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }
}
