# Glass Control Center

An iOS-style liquid-glass **Control Center overlay** for Android. It does not replace the system
Control Center; it draws on top of any app when you swipe down on an invisible strip at the top
of the screen (Accessibility overlay).

## Features
- Glass tiles, connectivity block, media card, brightness/volume pill sliders, Focus, torch, timer, etc.
- Staggered pop-in animation, background blur, press/overshoot animations, page swipe (main / media / connectivity list)
- Long-press: Orientation Lock card, flashlight strength slider, timer menu, connectivity detail
- Timer ruler card, edit mode (jiggle, remove / add controls)
- Real controls: brightness, volume, auto-rotate lock, silent mode, Focus (DND), flashlight + strength, media session
- Wi-Fi / Bluetooth / data / airplane / hotspot / NFC / VPN: live state, tap opens the system panel (Android blocks apps from toggling these)

## Build
Push to `main`; GitHub Actions builds the APK and publishes it to **Releases > Latest APK**
(also an artifact on the Actions run).

## Setup on the phone
1. Install the APK, open the app.
2. Enable Accessibility (Android 13+: App info > ⋮ > *Allow restricted settings* first).
3. Grant *Modify system settings*, *Notification access* (media card) and *Do Not Disturb access* (Focus / bell).
4. Swipe down on the top strip.
