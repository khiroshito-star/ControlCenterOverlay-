# Control Center Overlay (no root)
iOS-style glass Control Center overlay for Android. Uses an accessibility service to draw an invisible swipe-down strip at the top-center and a blurred glass panel over any app.

Controls: Wi-Fi, Bluetooth, mobile data, airplane (these open the system panel on modern Android, since apps can't toggle them), auto-rotate lock, Do Not Disturb, flashlight, brightness, volume, media player, screenshot, lock screen, camera, alarms, settings.

Build: push to GitHub, open Actions > Build APK, download the `ControlCenter-debug-apk` artifact, install the APK.
Setup: open the app and switch on the five items listed, then swipe down from the top-center.
Font: the app can import your own .ttf (e.g. one you are licensed to use). No font is bundled.
