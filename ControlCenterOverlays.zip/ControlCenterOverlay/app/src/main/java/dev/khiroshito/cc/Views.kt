package dev.khiroshito.cc

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup

/** Round/rounded-square glass button with an on/off state. */
class GlassButton(
    ctx: Context, icon: Int, private val circle: Boolean,
    private val onColor: Int, private val onIcon: Int, private val offColor: Int
) : View(ctx) {
    var active = false
        set(v) { if (field != v) { field = v; tween() } }
    var onTap: (() -> Unit)? = null
    var onHold: (() -> Unit)? = null

    private val bg = GradientDrawable().apply {
        shape = if (circle) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        setColor(offColor); setStroke(ctx.dpi(1f), EDGE)
    }
    private val ic: Drawable? = ctx.getDrawable(icon)?.mutate()
    private var curBg = offColor
    private var iconColor = Color.WHITE
    private var down = false
    private val hold = Runnable {
        if (down) {
            down = false
            animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onHold?.invoke()
        }
    }

    init { background = bg }

    private fun tween() {
        val fromBg = curBg; val fromIc = iconColor
        val toBg = if (active) onColor else offColor
        val toIc = if (active) onIcon else Color.WHITE
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200
            addUpdateListener {
                val t = it.animatedFraction
                curBg = ArgbEvaluator().evaluate(t, fromBg, toBg) as Int
                iconColor = ArgbEvaluator().evaluate(t, fromIc, toIc) as Int
                bg.setColor(curBg); invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (!circle) bg.cornerRadius = minOf(w, h) * 0.3f
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * 0.46f
        val cx = width / 2f; val cy = height / 2f
        ic?.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
        ic?.setTint(iconColor)
        ic?.draw(c)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                animate().scaleX(.93f).scaleY(.93f).setDuration(90).start()
                postDelayed(hold, 450)
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(hold)
                animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                if (down) {
                    down = false
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onTap?.invoke()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(hold); down = false
                animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
        }
        return true
    }
}

/** iOS-style vertical slider (brightness / volume). */
class VSlider(ctx: Context, icon: Int) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var onChange: ((Float) -> Unit)? = null
    /** Return false to block the drag (e.g. permission missing). */
    var onStart: (() -> Boolean)? = null

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GLASS }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = FILL }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(1f); color = EDGE
    }
    private val path = Path()
    private val ic: Drawable? = ctx.getDrawable(icon)?.mutate()
    private var allowed = true

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = w * 0.36f
        val rr = RectF(0f, 0f, w, h)
        c.drawRoundRect(rr, r, r, bgP)
        c.save()
        path.reset(); path.addRoundRect(rr, r, r, Path.Direction.CW); c.clipPath(path)
        c.drawRect(0f, h * (1f - value), w, h, fillP)
        c.restore()
        c.drawRoundRect(RectF(.5f, .5f, w - .5f, h - .5f), r, r, edgeP)
        val s = w * 0.42f; val cx = w / 2f; val cy = h - w * 0.5f
        ic?.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
        ic?.setTint(if (value * h > w * 0.62f) Color.rgb(85, 85, 90) else Color.WHITE)
        ic?.draw(c)
    }

    private fun setFrom(y: Float) {
        value = 1f - y / height
        onChange?.invoke(value)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                allowed = onStart?.invoke() ?: true
                parent?.requestDisallowInterceptTouchEvent(true)
                if (allowed) setFrom(e.y)
            }
            MotionEvent.ACTION_MOVE -> if (allowed) setFrom(e.y)
        }
        return true
    }
}

/** Places children on a 4-column grid; coordinates are in cell units (fractions allowed). */
class Grid(ctx: Context, private val rows: Int) : ViewGroup(ctx) {
    private class P(val x: Float, val y: Float, val w: Float, val h: Float)
    private val cells = LinkedHashMap<View, P>()
    private val gap = ctx.dpi(12f)
    private var pitch = 0f

    fun put(v: View, x: Float, y: Float, w: Float, h: Float) { cells[v] = P(x, y, w, h); addView(v) }

    private fun size(units: Float) = if (units >= 1f) units * pitch - gap else units * pitch

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        pitch = (w + gap) / 4f
        setMeasuredDimension(w, (rows * pitch - gap).toInt())
        for ((v, p) in cells) {
            v.measure(
                MeasureSpec.makeMeasureSpec(size(p.w).toInt(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(size(p.h).toInt(), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for ((v, p) in cells) {
            val x = (p.x * pitch).toInt(); val y = (p.y * pitch).toInt()
            v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
        }
    }
}
