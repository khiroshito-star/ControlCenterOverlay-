package dev.khiroshito.cc

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val rows = ArrayList<Pair<TextView, () -> Boolean>>()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(20f), dpi(28f), dpi(20f), dpi(28f)) }
        setContentView(ScrollView(this).apply { addView(root) })
        title("Control Center")
        note("No root needed. Turn on each item below once, then swipe down from the top-center of the screen.")

        step("1. Accessibility service (draws the overlay)", { a11yOn() }) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        step("2. Modify system settings (brightness, auto-rotate)", { Settings.System.canWrite(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        step("3. Do Not Disturb access", { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        step("4. Notification access (media player tile)", { listenerOn() }) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        step("5. Bluetooth permission (Android 12+)", { btOk() }) {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }

        note("Trigger strip (invisible area at the top)")
        slider("Width", 20, 100, "strip_w", 50)
        slider("Height (dp)", 16, 80, "strip_h", 36)

        button("Choose font (.ttf)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 7)
        }
        button("Reset font") { File(filesDir, "font.ttf").delete(); toast("Font reset") }
        button("Open Control Center (test)") {
            val s = CCService.instance
            if (s == null) toast("Turn on the accessibility service first") else s.openPanel()
        }
        note("On Android 13+, if the accessibility switch is greyed out: App info > menu (3 dots) > Allow restricted settings.")
    }

    override fun onResume() { super.onResume(); rows.forEach { (tv, ok) -> mark(tv, ok()) } }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7 && res == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openInputStream(data.data!!)!!.use { i -> File(filesDir, "font.ttf").outputStream().use { o -> i.copyTo(o) } }
                toast("Font imported")
            } catch (e: Exception) { toast("Could not read that file") }
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/${CCService::class.java.name}")
    }
    private fun listenerOn() = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
    private fun btOk() = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun mark(tv: TextView, ok: Boolean) { tv.text = if (ok) "ON" else "OFF"; tv.setTextColor(if (ok) 0xFF34C759.toInt() else 0xFFFF3B30.toInt()) }

    private fun title(t: String) = root.addView(TextView(this).apply { text = t; textSize = 26f; setPadding(0, 0, 0, dpi(8f)) })
    private fun note(t: String) = root.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, dpi(10f), 0, dpi(6f)) })
    private fun button(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })

    private fun step(label: String, ok: () -> Boolean, open: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dpi(6f), 0, dpi(6f)) }
        row.addView(TextView(this).apply { text = label; textSize = 14f }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val st = TextView(this).apply { textSize = 13f; setPadding(dpi(8f), 0, dpi(8f), 0) }
        rows.add(st to ok)
        row.addView(st)
        row.addView(Button(this).apply { text = "Open"; setOnClickListener { open() } })
        root.addView(row)
    }

    private fun slider(label: String, min: Int, max: Int, key: String, def: Int) {
        val tv = TextView(this).apply { textSize = 13f }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = prefs().getInt(key, def) - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { tv.text = "$label: ${p + min}"; if (u) prefs().edit().putInt(key, p + min).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        tv.text = "$label: ${sb.progress + min}"
        root.addView(tv); root.addView(sb)
    }
}
