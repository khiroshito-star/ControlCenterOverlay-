package dev.khiroshito.cc

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class CCService : AccessibilityService() {
    companion object { var instance: CCService? = null }

    private lateinit var wm: WindowManager
    private var strip: View? = null
    private var panel: PanelView? = null
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> rebuildStrip() }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs().registerOnSharedPreferenceChangeListener(prefListener)
        rebuildStrip()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) { closeNow(); rebuildStrip() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        prefs().unregisterOnSharedPreferenceChangeListener(prefListener)
        closeNow()
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        strip = null; instance = null
        return super.onUnbind(intent)
    }

    /** The invisible swipe-down trigger at the top-center of the screen. */
    fun rebuildStrip() {
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val pct = prefs().getInt("strip_w", 50)
        val hdp = prefs().getInt("strip_h", 36)
        val w = (resources.displayMetrics.widthPixels * pct / 100f).toInt()
        val v = View(this)
        var y0 = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { y0 = e.rawY; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - y0 > dpi(18f)) { fired = true; openPanel() }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            w, dpi(hdp.toFloat()), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        try { wm.addView(v, lp); strip = v } catch (_: Exception) {}
    }

    fun openPanel() {
        if (panel != null || !::wm.isInitialized) return
        val p = PanelView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 60
        }
        try { wm.addView(p, lp); panel = p; p.animateIn() } catch (_: Exception) {}
    }

    fun closePanel() {
        val p = panel ?: return
        panel = null
        p.animateOut { try { wm.removeView(p) } catch (_: Exception) {} }
    }

    private fun closeNow() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    fun launch(i: Intent) {
        closePanel()
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {}
    }

    fun global(action: Int) {
        closePanel()
        android.os.Handler(mainLooper).postDelayed({ performGlobalAction(action) }, 450)
    }
}
