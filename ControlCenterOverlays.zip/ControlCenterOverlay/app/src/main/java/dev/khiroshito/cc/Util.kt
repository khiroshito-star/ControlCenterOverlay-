package dev.khiroshito.cc

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.io.File

val GLASS = Color.argb(64, 255, 255, 255)
val EDGE = Color.argb(60, 255, 255, 255)
val FILL = Color.argb(242, 255, 255, 255)
val DARK = Color.rgb(28, 28, 30)

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = dp(v).toInt()
fun Context.prefs() = getSharedPreferences("cc", Context.MODE_PRIVATE)

/** Optional user-supplied font (imported from the app screen). Nothing is bundled. */
fun Context.customFont(): Typeface? {
    val f = File(filesDir, "font.ttf")
    return if (f.exists()) runCatching { Typeface.createFromFile(f) }.getOrNull() else null
}

fun glassBg(ctx: Context, radiusDp: Float) = GradientDrawable().apply {
    setColor(GLASS)
    cornerRadius = ctx.dp(radiusDp)
    setStroke(ctx.dpi(1f), EDGE)
}
