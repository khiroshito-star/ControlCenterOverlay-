package dev.khiroshito.cc

import android.service.notification.NotificationListenerService

/** Empty on purpose: enabling notification access lets the panel read "now playing" media sessions. */
class MediaListener : NotificationListenerService()
