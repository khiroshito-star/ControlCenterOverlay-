package dev.khiroshito.cc

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

@Suppress("DEPRECATION")
class PanelView(private val svc: CCService) : FrameLayout(svc) {
    private val tf: Typeface? = svc.customFont()
    private val cardW = minOf(resources.displayMetrics.widthPixels - svc.dpi(32f), svc.dpi(360f))
    private val card = FrameLayout(svc)
    private val grid = Grid(svc, 5)

    private val wifiM = svc.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val cm = svc.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val nm = svc.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val cam = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val bta = (svc.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val camId: String? = try {
        cam.cameraIdList.firstOrNull { cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
    } catch (_: Exception) { null }

    private lateinit var airplane: GlassButton
    private lateinit var mobile: GlassButton
    private lateinit var wifi: GlassButton
    private lateinit var bt: GlassButton
    private lateinit var rot: GlassButton
    private lateinit var dnd: GlassButton
    private lateinit var flash: GlassButton
    private lateinit var bright: VSlider
    private lateinit var vol: VSlider
    private val mTitle = TextView(svc)
    private val mArtist = TextView(svc)
    private val mPlay = ImageView(svc)
    private var torch = false
    private var downY = 0f

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == camId) { torch = enabled; post { flash.active = enabled } }
        }
    }

    private fun writeIntent() = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${svc.packageName}"))
    private fun btOk() = Build.VERSION.SDK_INT < 31 ||
        svc.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun btn(icon: Int, circle: Boolean, on: Int, onIcon: Int = Color.WHITE, off: Int = GLASS) =
        GlassButton(svc, icon, circle, on, onIcon, off)

    private fun tile(icon: Int, on: Int = FILL, onIcon: Int = DARK) = btn(icon, false, on, onIcon)

    private fun build() {
        val circleOff = Color.argb(120, 40, 40, 46)
        // Connectivity block
        grid.put(View(svc).apply { background = glassBg(svc, 34f) }, 0f, 0f, 2f, 2f)
        airplane = btn(R.drawable.ic_airplane, true, Color.rgb(255, 149, 0), off = circleOff)
        mobile = btn(R.drawable.ic_cell, true, Color.rgb(52, 199, 89), off = circleOff)
        wifi = btn(R.drawable.ic_wifi, true, Color.rgb(10, 132, 255), off = circleOff)
        bt = btn(R.drawable.ic_bt, true, Color.rgb(10, 132, 255), off = circleOff)
        grid.put(airplane, 0.2f, 0.2f, 0.7f, 0.7f); grid.put(mobile, 0.95f, 0.2f, 0.7f, 0.7f)
        grid.put(wifi, 0.2f, 0.95f, 0.7f, 0.7f); grid.put(bt, 0.95f, 0.95f, 0.7f, 0.7f)

        // Media block
        val pad = svc.dpi(14f)
        val mbox = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL; background = glassBg(svc, 28f); setPadding(pad, pad, pad, pad) }
        mTitle.apply { setTextColor(Color.WHITE); textSize = 15f; setTypeface(tf ?: Typeface.DEFAULT, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        mArtist.apply { setTextColor(Color.argb(170, 255, 255, 255)); textSize = 13f; setTypeface(tf ?: Typeface.DEFAULT); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        mbox.addView(mTitle); mbox.addView(mArtist)
        mbox.addView(View(svc), LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        val row = LinearLayout(svc).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        fun ib(iv: ImageView, res: Int, act: (MediaController) -> Unit) {
            iv.setImageResource(res); iv.setColorFilter(Color.WHITE); iv.setPadding(svc.dpi(8f), svc.dpi(8f), svc.dpi(8f), svc.dpi(8f))
            iv.setOnClickListener { controller()?.let(act); postDelayed({ refreshMedia() }, 300) }
            row.addView(iv, LinearLayout.LayoutParams(0, svc.dpi(44f), 1f))
        }
        ib(ImageView(svc), R.drawable.ic_prev) { it.transportControls.skipToPrevious() }
        ib(mPlay, R.drawable.ic_play) { c -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play() }
        ib(ImageView(svc), R.drawable.ic_next) { it.transportControls.skipToNext() }
        mbox.addView(row, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        mbox.setOnClickListener { if (controller() == null) svc.launch(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        grid.put(mbox, 2f, 0f, 2f, 2f)

        // Row 2-3 tiles + sliders
        rot = tile(R.drawable.ic_rotate, Color.rgb(255, 59, 48), Color.WHITE)
        dnd = tile(R.drawable.ic_moon, Color.rgb(94, 92, 230), Color.WHITE)
        flash = tile(R.drawable.ic_flash)
        val shot = tile(R.drawable.ic_shot)
        bright = VSlider(svc, R.drawable.ic_brightness)
        vol = VSlider(svc, R.drawable.ic_volume)
        grid.put(rot, 0f, 2f, 1f, 1f); grid.put(dnd, 1f, 2f, 1f, 1f)
        grid.put(bright, 2f, 2f, 1f, 2f); grid.put(vol, 3f, 2f, 1f, 2f)
        grid.put(flash, 0f, 3f, 1f, 1f); grid.put(shot, 1f, 3f, 1f, 1f)
        // Row 4 shortcuts
        val lock = tile(R.drawable.ic_lock); val camera = tile(R.drawable.ic_camera)
        val alarm = tile(R.drawable.ic_alarm); val sett = tile(R.drawable.ic_settings)
        grid.put(lock, 0f, 4f, 1f, 1f); grid.put(camera, 1f, 4f, 1f, 1f)
        grid.put(alarm, 2f, 4f, 1f, 1f); grid.put(sett, 3f, 4f, 1f, 1f)

        // Actions
        airplane.onTap = { svc.launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        mobile.onTap = { svc.launch(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        wifi.onTap = {
            if (Build.VERSION.SDK_INT >= 29) svc.launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else { try { wifiM.isWifiEnabled = !wifiM.isWifiEnabled } catch (_: Exception) {}; postDelayed({ refresh() }, 500) }
        }
        wifi.onHold = { svc.launch(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        bt.onTap = {
            val a = bta
            if (a != null && Build.VERSION.SDK_INT < 33 && btOk()) {
                try { if (a.isEnabled) a.disable() else a.enable() } catch (_: Exception) {}
                postDelayed({ refresh() }, 700)
            } else svc.launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        bt.onHold = { svc.launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        rot.onTap = {
            if (Settings.System.canWrite(svc)) {
                val cur = Settings.System.getInt(svc.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
                Settings.System.putInt(svc.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
                refresh()
            } else svc.launch(writeIntent())
        }
        dnd.onTap = {
            if (nm.isNotificationPolicyAccessGranted) {
                val all = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
                nm.setInterruptionFilter(if (all) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
                postDelayed({ refresh() }, 300)
            } else svc.launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        flash.onTap = { try { camId?.let { cam.setTorchMode(it, !torch) } } catch (_: Exception) {} }
        shot.onTap = { svc.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }
        lock.onTap = { svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }
        camera.onTap = { svc.launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        alarm.onTap = { svc.launch(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        sett.onTap = { svc.launch(Intent(Settings.ACTION_SETTINGS)) }

        bright.onStart = {
            if (Settings.System.canWrite(svc)) true else { svc.launch(writeIntent()); false }
        }
        bright.onChange = { v ->
            try {
                Settings.System.putInt(svc.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(svc.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (v * 255).toInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        }
        vol.onChange = { v ->
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0)
        }
    }

    private fun controller(): MediaController? = try {
        (svc.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager)
            .getActiveSessions(ComponentName(svc, MediaListener::class.java)).firstOrNull()
    } catch (_: Exception) { null }

    private fun refreshMedia() {
        val c = controller()
        if (c == null) {
            mTitle.text = "Not Playing"; mArtist.text = "Tap to allow notification access"
            mPlay.setImageResource(R.drawable.ic_play); return
        }
        val md = c.metadata
        mTitle.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Playing"
        mArtist.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        mPlay.setImageResource(if (c.playbackState?.state == PlaybackState.STATE_PLAYING) R.drawable.ic_pause else R.drawable.ic_play)
    }

    fun refresh() {
        try { wifi.active = wifiM.isWifiEnabled } catch (_: Exception) {}
        try { bt.active = btOk() && bta?.isEnabled == true } catch (_: Exception) {}
        airplane.active = Settings.Global.getInt(svc.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        mobile.active = try {
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (_: Exception) { false }
        rot.active = Settings.System.getInt(svc.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        dnd.active = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        flash.active = torch
        bright.value = Settings.System.getInt(svc.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        vol.value = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        refreshMedia()
    }

    fun animateIn() {
        alpha = 0f
        card.alpha = 0f; card.scaleX = .86f; card.scaleY = .86f; card.translationY = -svc.dp(40f)
        animate().alpha(1f).setDuration(220).start()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(420).setInterpolator(OvershootInterpolator(0.9f)).start()
    }

    fun animateOut(end: () -> Unit) {
        animate().alpha(0f).setDuration(200).start()
        card.animate().alpha(0f).scaleX(.92f).scaleY(.92f).translationY(-svc.dp(30f))
            .setDuration(200).withEndAction(end).start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        try { cam.registerTorchCallback(torchCb, null) } catch (_: Exception) {}
        refresh()
    }

    override fun onDetachedFromWindow() {
        try { cam.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        super.onDetachedFromWindow()
    }

    init {
        setBackgroundColor(Color.argb(70, 0, 0, 0))
        card.pivotX = cardW / 2f; card.pivotY = 0f
        card.isClickable = true
        card.addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(card, LayoutParams(cardW, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = svc.dpi(72f) })
        build()
        setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_UP -> svc.closePanel()
            }
            true
        }
    }
}
